import tkinter as tk
from tkinter import messagebox
import sqlite3


# Database setup
def setup_database():
    conn = sqlite3.connect("moviehouse.db")
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS room (
        id INTEGER PRIMARY KEY,
        cost REAL
    )
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS movie (
        id INTEGER PRIMARY KEY,
        title VARCHAR(255),
        genre VARCHAR(255),
        is_deleted INTEGER DEFAULT 0,
        cost REAL
    )
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS room_record (
        id INTEGER PRIMARY KEY,
        room_id INTEGER,
        total_cost REAL,
        is_finished INTEGER DEFAULT 0,
        FOREIGN KEY(room_id) REFERENCES room(id)
    )
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS room_movie_record (
        id INTEGER PRIMARY KEY,
        room_record_id INTEGER,
        movie_id INTEGER,
        FOREIGN KEY(room_record_id) REFERENCES room_record(id),
        FOREIGN KEY(movie_id) REFERENCES movie(id)
    )
    """)

    # Insert sample room data
    cursor.executemany("INSERT OR IGNORE INTO room (id, cost) VALUES (?, ?)", [
        (1, 100), (2, 150), (3, 200), (4, 250)
    ])

    conn.commit()
    conn.close()


# Main App Window
class MovieHouseApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Movie House")
        self.root.geometry("800x500")

        # Frames
        self.register_frame = tk.LabelFrame(root, text="Register", width=400, height=150)
        self.register_frame.place(x=50, y=0)

        self.movie_frame = tk.LabelFrame(root, text="Movies", width=300, height=200)
        self.movie_frame.place(x=50, y=200)

        self.room_frame = tk.LabelFrame(root, text="Rooms", width=400, height=400)
        self.room_frame.place(x=400, y=50)

        # Register Section
        tk.Label(self.register_frame, text="Title").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.movie_title = tk.Entry(self.register_frame, width=20)
        self.movie_title.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(self.register_frame, text="Cost").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.movie_cost = tk.Entry(self.register_frame, width=20)
        self.movie_cost.grid(row=1, column=1, padx=5, pady=5)

        tk.Label(self.register_frame, text="Genre").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.movie_genre = tk.Entry(self.register_frame, width=20)
        self.movie_genre.grid(row=2, column=1, padx=5, pady=5)

        tk.Button(self.register_frame, text="Add Movie", command=self.add_movie).grid(row=3, column=0, columnspan=2, pady=10)

        # Movies Section
        self.movies_listbox = tk.Listbox(self.movie_frame, width=40, height=8)
        self.movies_listbox.pack(pady=5)

        tk.Button(self.movie_frame, text="Remove Movie", command=self.remove_movie).pack(pady=5)

        # Genre Checkboxes
        self.genre_vars = {
            "Adventure": tk.IntVar(),
            "Comedy": tk.IntVar(),
            "Fantasy": tk.IntVar(),
            "Romance": tk.IntVar(),
            "Tragedy": tk.IntVar()
        }
        genre_row = 0
        for genre, var in self.genre_vars.items():
            tk.Checkbutton(self.movie_frame, text=genre, variable=var).pack(anchor="w")

        # Rooms Section
        self.room_buttons = []
        for i in range(1, 5):
            btn = tk.Button(self.room_frame, text=f"Room {i}", width=20, command=lambda r=i: self.open_room(r))
            btn.grid(row=i - 1, column=0, padx=20, pady=10)
            self.room_buttons.append(btn)

        self.load_movies()

    def add_movie(self):
        title = self.movie_title.get()
        cost = self.movie_cost.get()
        genre = self.movie_genre.get()

        if not title or not cost or not genre:
            messagebox.showerror("Error", "All fields are required.")
            return

        try:
            cost = float(cost)
        except ValueError:
            messagebox.showerror("Error", "Cost must be a number.")
            return

        conn = sqlite3.connect("moviehouse.db")
        cursor = conn.cursor()
        cursor.execute("INSERT INTO movie (title, genre, cost) VALUES (?, ?, ?)", (title, genre, cost))
        conn.commit()
        conn.close()

        self.movie_title.delete(0, tk.END)
        self.movie_cost.delete(0, tk.END)
        self.movie_genre.delete(0, tk.END)
        self.load_movies()
        messagebox.showinfo("Success", "Movie added successfully!")

    def remove_movie(self):
        selected_movie = self.movies_listbox.curselection()
        if not selected_movie:
            messagebox.showerror("Error", "No movie selected.")
            return

        movie_title = self.movies_listbox.get(selected_movie)
        conn = sqlite3.connect("moviehouse.db")
        cursor = conn.cursor()
        cursor.execute("UPDATE movie SET is_deleted = 1 WHERE title = ?", (movie_title,))
        conn.commit()
        conn.close()

        self.load_movies()
        messagebox.showinfo("Success", "Movie removed successfully!")

    def load_movies(self):
        self.movies_listbox.delete(0, tk.END)
        conn = sqlite3.connect("moviehouse.db")
        cursor = conn.cursor()
        cursor.execute("SELECT title FROM movie WHERE is_deleted = 0")
        movies = cursor.fetchall()
        conn.close()

        for movie in movies:
            self.movies_listbox.insert(tk.END, movie[0])

    def open_room(self, room_id):
        RoomWindow(self.root, room_id)


# Room Window
class RoomWindow:
    def __init__(self, parent, room_id):
        self.room_id = room_id
        self.top = tk.Toplevel(parent)
        self.top.title(f"Room {room_id}")
        self.top.geometry("400x300")

        tk.Label(self.top, text=f"Room {room_id}").pack(pady=10)


# Main Program
if __name__ == "__main__":
    setup_database()
    root = tk.Tk()
    app = MovieHouseApp(root)
    root.mainloop()